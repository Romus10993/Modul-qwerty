using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PohybHrace : MonoBehaviour
{
    private Rigidbody hrac;
    public GameObject pauzaMenu;
    //public GameObject pozadiBooster;
    public GameObject pozadiNormal;
    //public GameObject pozadiZivot;
    public GameObject pozadiEnemy;
    private int pocetBodu;
    private int pocetZivotu = 1;
    public Text skore;
    public Text zivoty;
    // Start is called before the first frame update
    void Start()
    {
        hrac = GetComponent<Rigidbody>();
        Time.timeScale = 1;
        pauzaMenu.SetActive(false);
        //pozadiBooster.SetActive(false);
        pozadiNormal.SetActive(true);
        //pozadiZivot.SetActive(false);
        pozadiEnemy.SetActive(false);
        skore.text = "Po�et bod�: " + this.pocetBodu;
        zivoty.text = "�ivoty: " + this.pocetZivotu;
    }

    // Update is called once per frame
    void Update()
    {
        /*
        if (Input.GetKeyDown(KeyCode.Space) && this.transform.position.y < 8) {
            //hrac.AddForce(new Vector3(0f, 500f, 0f));
            hrac.velocity = new Vector3(0f, 5f, 0f);
        }
         * */
        if (Input.GetMouseButtonDown(0) && this.transform.position.y < 8)
        {
            //hrac.AddForce(new Vector3(0f, 500f, 0f));
            hrac.velocity = new Vector3(0f, 5f, 0f);
        }
    }

    private void OnTriggerEnter(Collider ciziObjekt) {
        if (ciziObjekt.gameObject.tag == "Prekazka") {
            pocetZivotu -= 1;
            zivoty.text = "�ivoty: " + this.pocetZivotu;

            pozadiEnemy.SetActive(true);
            //pozadiBooster.SetActive(false);
            pozadiNormal.SetActive(false);
            //pozadiZivot.SetActive(false);

            if(pocetZivotu <= 0)
            {
                Time.timeScale = 0;
                pauzaMenu.SetActive(true);
            }
        }
        if (ciziObjekt.gameObject.tag == "Enemy")
        {
            pocetZivotu -= 2;
            zivoty.text = "�ivoty: " + this.pocetZivotu;

            pozadiEnemy.SetActive(true);
            //pozadiBooster.SetActive(false);
            pozadiNormal.SetActive(false);
            //pozadiZivot.SetActive(false);

            if (pocetZivotu <= 0)
            {
                Time.timeScale = 0;
                pauzaMenu.SetActive(true);
            }
        }
        if (ciziObjekt.gameObject.tag == "Bod")
        {
            pocetBodu++;
            skore.text = "Po�et bod�: " + this.pocetBodu;

            pozadiEnemy.SetActive(false);
            //pozadiBooster.SetActive(false);
            pozadiNormal.SetActive(true);
            //pozadiZivot.SetActive(false);
        }
        if (ciziObjekt.gameObject.tag == "Booster")
        {
            pocetBodu += 5;
            skore.text = "Po�et bod�: " + this.pocetBodu;

            /*pozadiEnemy.SetActive(false);
            pozadiBooster.SetActive(true);
            pozadiNormal.SetActive(false);
            pozadiZivot.SetActive(false);*/
        }
        if(ciziObjekt.gameObject.tag == "ExtraLife")
        {
            pocetZivotu += 1;
            zivoty.text = "�ivoty: " + this.pocetZivotu;

            /*pozadiEnemy.SetActive(false);
            pozadiBooster.SetActive(false);
            pozadiNormal.SetActive(false);
            pozadiZivot.SetActive(true);*/
        }
    }

    public void ReloadSceny() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
