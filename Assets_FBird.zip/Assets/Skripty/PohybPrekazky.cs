using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PohybPrekazky : MonoBehaviour
{
    void Update()
    {
        Vector3 posun = new Vector3(-5f, 0f, 0f);
        this.transform.position += posun * Time.deltaTime;
    }
}
