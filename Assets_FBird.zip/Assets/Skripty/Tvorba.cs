using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tvorba : MonoBehaviour
{
    public GameObject prekazka;
    public GameObject booster;
    public GameObject extraLife;
    public GameObject enemy;
    public float cas1;
    public float cas2;
    public float cas3;
    public float cas4;


    void Start()
    {
        cas1 = 0;
        cas2 = 0;
        cas3 = 0;
        cas4 = 0;
    }

    // Update is called once per frame
    void Update()
    {
        cas1 += Time.deltaTime;
        cas2 += Time.deltaTime;
        cas3 += Time.deltaTime;
        cas4 += Time.deltaTime;

        if (cas1 > 1.5)
        {
            GameObject novaPrekazka = Instantiate(prekazka);
            novaPrekazka.transform.position = new Vector3(12, Random.Range(-2, 3), 0);
            cas1 = 0;
            //Destroy(novaPrekazka, 10);
        }
        if (cas2 > 3)
        {
            GameObject novyBooster = Instantiate(booster);
            novyBooster.transform.position = new Vector3(10, Random.Range(3,8), -5.5f);
            cas2 = 0;
            //Destroy(novyBooster, 10);
        }
        if (cas3 > 4.5)
        {
            GameObject novyZivot = Instantiate(extraLife);
            novyZivot.transform.position = new Vector3(10, Random.Range(2, 7), -5.5f);
            cas3 = 0;
            //Destroy(novyZivot, 10);
        }
        if (cas4 > 6)
        {
            GameObject novyNepritel = Instantiate(enemy);
            novyNepritel.transform.position = new Vector3(10, Random.Range(1, 9), -5.5f);
            cas4 = 0;
            //Destroy(novyZivot, 10);
        }


    }
}
