using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PosunPozadi : MonoBehaviour
{

    public Renderer pozadi;
    public float rychlostPosunu;

    void Update()
    {
        Vector2 velikostPosunu = new Vector2(rychlostPosunu * Time.deltaTime, 0f);
        pozadi.material.mainTextureOffset += velikostPosunu;
    }
}
